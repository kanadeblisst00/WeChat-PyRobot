from py_process_hooker import inject_python_and_open_console


if __name__ == "__main__":
    process_name = "WeChat.exe"
    inject_python_and_open_console(process_name)








